import UIKit

/* Variables and Constants
   Homework Assignment #1
 */

// The artist of this song is Eminem
// The release year of the song is the year 2020
// The genre is alternative hip-hop/rap
// The duration of this song is 2 minutes and 57 seconds
// The titel of the song is Little Engine
// The album that the song belongs to is Music To Be Murdered By
// The song is placed as number 15 in the album

let Artist : String = "Eminem"
var YearReleased : Int = 2020
var Genre : String = "Alternative Hip-Hop/Rap"
var Duration : TimeInterval = 177
let Titel : String = "Little Engine"
let Album : String = "Music To Be Murdered By"
var Number : Int = 15

print(Artist);
print(YearReleased);
print(Genre);
print(Duration);
print(Titel);
print(Album);
print(Number);

